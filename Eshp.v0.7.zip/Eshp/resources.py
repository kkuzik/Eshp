<RCC>
  <qresource prefix="/">
    <file>icon.png</file>
  </qresource>
</RCC>
